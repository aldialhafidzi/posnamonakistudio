<div class="modal fade" id="modal_save_table" tabindex="-1" role="dialog" aria-labelledby="modal_save_tableLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="judul_modal_save_table">Simpan Form Barang</h5>
                <button type="button" class="close hapus-tabel-tambah-barang"  aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Simpan form barang yang telah diisi ?

            </div>
            <div class="modal-footer">

              <button type="button"  class="btn btn-sm btn-success save-tabel-tambah-barang">Ya</button>
              <button type="button" class="btn btn-sm btn-danger hapus-tabel-tambah-barang" data-dismiss="modal">Tidak</button>
              <button type="button" class="btn btn-sm btn-secondary batal-tabel-tambah-barang" data-dismiss="modal">Kembali</button>
            </div>
        </div>
    </div>
</div>
