<?php $__env->startSection('content'); ?>
  <div class="panel-login">
    <center><img style="width: 200px;" src="<?php echo e(URL::asset('images/qshop.png')); ?>" alt=""></center>
    <br>

    <div class="container-fluid">
      <div class="panel panel-default col-sm-12">
        <div class="panel-body">

          <form method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>

            <div class="form-group">
              <label for="username">Username</label>
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text"><i class="glyphicon glyphicon-user"></i></span>
                </div>
                <input id="username" type="text" placeholder="Username" class="form-control<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e(old('username')); ?>" required autofocus>

                <?php if($errors->has('username')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('username')); ?></strong>
                    </span>
                <?php endif; ?>

              </div>
            </div>

            <div class="form-group">
              <label for="password">Password</label>
              <div class="input-group">
                <div class="input-group-prepend">
                  <span class="input-group-text"><i class="glyphicon glyphicon-lock"></i></span>
                </div>

                <input placeholder="Password" id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                <?php if($errors->has('password')): ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($errors->first('password')); ?></strong>
                    </span>
                <?php endif; ?>
              </div>
            </div>

            <div class="form-group">
              <div class="custom-control custom-checkbox">
                <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                <label class="custom-control-label" for="remember">Remember me</label>
              </div>

            </div>
            <br>
              <div class="row">

                <div class="col-sm-7  offset-sm-4">
                  <button type="submit" name="login" class="btn btn btn-outline-primary">
                    <span class="glyphicon glyphicon-log-in" aria-hidden="true"></span>
                      &nbsp; Login
                  </button>
                </div>
              </div>
          </form>

        </div>
      </div>
    </div>


  <br>
  <p class="text-center"> Applikasi Penjualan &copy; 2018 by Aldi </p>

  <hr style="border-color:#999; border-style:dashed;">
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.applogin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>